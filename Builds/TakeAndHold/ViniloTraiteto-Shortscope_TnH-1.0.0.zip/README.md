# Shortscope

Small cramped map. Grabbed a chunk out of Runescape's map and used it as a base to get myself out of a mapper's block.

If you figured where on Runescape I took this chunk off, congrats I have no idea. I've never played Runescape sorry, it just looked like a cool layout for Take and Hold.

Take and Hold version. Holds on the outside, supplies on the inside. Any building big enough to hold a supply likely has one (or more).

# TnH Version Changelog:

## 1.0.0
- Initial release

## 1.0.1
- Corrected dependencies
- Tweaked manifest and description jsons