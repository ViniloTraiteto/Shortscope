# Shortscope

Small cramped map. Grabbed a chunk out of Runescape's map and used it as a base to get myself out of a mapper's block.

If you figured where on Runescape I took this chunk off, congrats I have no idea. I've never played Runescape sorry, it just looked like a cool layout for Take and Hold.

Got the sandbox version out first if anyone wants to mess around with it. The watchtower is pretty cool for sniping.

# Sandbox Version Changelog:

## 1.0.1
- Added material definitions to all buildings. (Buildings are now made of drywall, very pierceable with large calibers!)
- Tweaked reverb area
- Improved occlusion
- Corrected dependencies

## 1.0.0
- Initial release
